<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mink extends CI_model {
    function searchMain($key) {
        
        $this->db->select('id_Buku, pengarang, judul, halaman, genre, gambar, url_sumber');
        $this->db->from('ebook');
        $this->db->join('pengarang', 'ebook.id_pengarang = pengarang.user_id');
        if ($this->session->userdata('pageuser')=='1'){
            $this->db->where('ebook.id_pengarang = '.$this->session->userdata('userid'));
            if (!($key === "kosongasdfg")){
                $this->db->like('judul', $key);
            }
        } else {
            if (!($key === "kosongasdfg")){
                $this->db->like('judul', $key);
                $this->db->or_like('genre', $key);
            }
        }
        
        return $this->db->get()->result_array(); 
    }

    function read($table) {
        return $this->db->get($table)->result_array();
    }

    function read_row($id) {
        return $this->db->get_where('ebook',['id_Buku' => $id])->row_array();
    }

    function readMain() {
        $this->db->select('pengarang, judul, halaman, genre, gambar, url_sumber');
        $this->db->from('ebook');
        $this->db->join('pengarang', 'ebook.id_pengarang = pengarang.user_id');
        return $this->db->get()->result_array(); 
    }

    function readUser() {
        $this->db->select('id_Buku, pengarang, judul, halaman, genre, gambar, url_sumber');
        $this->db->from('ebook');
        $this->db->join('pengarang', 'ebook.id_pengarang = pengarang.user_id');
        $this->db->where('ebook.id_pengarang = '.$this->session->userdata('userid'));
        return $this->db->get()->result_array(); 
    }

    function create(){
        // ambil data file
        // var_dump($_FILES);
        $namaFile = $_FILES['input4']['name'];
        $namaSementara = $_FILES['input4']['tmp_name'];

        // tentukan lokasi file akan dipindahkan
        $dirUpload = getcwd()."/assets/data/pdf/";
        
        while (is_file($dirUpload.$namaFile)){
            $namaFile = "x".$namaFile;
        }

        // pindahkan file
        $terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);

        $data = file_get_contents($_FILES['input3']['tmp_name']);
        $bin = base64_encode($data);

        $judul = $this->input->post('input');
        $pengarang = $this->session->userdata('userid');
        $genre = $this->input->post('input1');
        $halaman = $this->input->post('input2');
        $url = "assets/data/pdf/".$namaFile;
        $gambar = $bin;

        $data = [
            'judul' => $judul,
            'id_pengarang' => $pengarang,
            'halaman' => $halaman,
            'genre' => $genre,
            'gambar' => $gambar,
            'url_sumber' => $url
        ];

        $this->db->insert('ebook', $data);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('pesan', 'Ditambah');
            redirect('ink/user', 'refresh');
        }

    }

    function daftar(){
        $nama = $this->input->post('input');
        $username = $this->input->post('input0');
        $password = $this->input->post('input1');
        $email = $this->input->post('input2');

        $data = [
            'user' => $username,
            'pass' => $password,
            'email' => $email,
            'pengarang' => $nama
        ];

        $this->db->insert('pengarang', $data);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('pesan', 'daftar');
            redirect('ink/login', 'refresh');
        }

    }

    function ubah($id){
        if ($_FILES['input3']['tmp_name'] != "") {
            $data = file_get_contents($_FILES['input3']['tmp_name']);
            $bin = base64_encode($data);
            $false = "";
        }

        $judul = $this->input->post('input');
        $genre = $this->input->post('input1');
        $halaman = $this->input->post('input2');
        
        if (isset($false)) {
            $gambar = $bin;
            $data = [
                'judul' => $judul,
                'halaman' => $halaman,
                'genre' => $genre,
                'gambar' => $gambar,
            ];
        } else {
            $data = [
                'judul' => $judul,
                'halaman' => $halaman,
                'genre' => $genre
            ];
        }
        // echo 'id';
        // echo $id;
        $this->db->where('id_Buku', $id);
        $this->db->update('ebook', $data);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('pesan', 'Diubah');
            redirect('ink/user', 'refresh');
        }

    }

    function removeFile($filename){
		echo getcwd();
		$file = getcwd().$filename;
		if (!unlink($file)){
			die ("Error deleting $file");
		}
	}

    function hapus($id){
        $this->removeFile("/".$this->db->get_where('ebook',['id_Buku' => $id])->row_array()["url_sumber"]);
        $this->db->where('id_Buku',$id);
        $this->db->delete('ebook');
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('pesan', 'Dihapus');
            redirect('ink/user', 'refresh');
        }
    }
}