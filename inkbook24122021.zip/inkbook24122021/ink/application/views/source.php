<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>ink-Library</title>

	<!-- Bootstrap core CSS-->
	<!-- <link rel="stylesheet" href="<?=base_url('assets/css/bootstrap.min.css')?>"> -->
	<link rel="stylesheet" href="<?=base_url('assets/css/style.css')?>">
	<!-- <script src="<?=base_url('assets/js/myscript.js')?>"></script> -->
	<script>
		function hideSearchText() {
			var x = document.getElementById("search");
			var y = document.getElementById("cari");
			// console.log(window.innerWidth - 305);
			if (x.style.width === "0px" || x.style.width === "") {
				x.style.width = (window.innerWidth - 340)+"px";
				x.style.marginLeft = "10px";
				y.style.color = "#ffffff";
				x.focus();
			}else {
				x.style.width = "0px";
				x.style.marginLeft = "0px";
				y.style.color = "#3c7484";
				x.blur();
    		}
 		}

	</script>
	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	<!-- Bootstrap core JS-->
	<!-- <script src="<?=base_url('assets/js/bootstrap.bundle.min.js')?>"></script>
	<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script> -->
</head>
<body style="overflow-x: hidden;">