<footer>
	<div class="footer-content">
		<ul class="socials">
			<li><a href="#"><i class="fab fa-facebook"></i></a></li>
			<li><a href="#"><i class="fab fa-twitter"></i></a></li>
			<li><a href="#"><i class="fab fa-google-plus"></i></a></li>
			<li><a href="#"><i class="fab fa-youtube"></i></a></li>
			<li><a href="#"><i class="fab fa-linkedin"></i></a></li>
		</ul>
	</div>
	<div class="footer-bottom">
		<p>Copyright © 2021. All rights reserved.</p>
	</div>		
</footer>

<script>
	var cari = document.getElementById("search");
	var wadah = document.getElementById("data");

	cari.addEventListener('keyup', function() {
		var xhr = new XMLHttpRequest();

		xhr.onreadystatechange = function(){
			// console.log('<?php echo str_replace('\\', '\\\\', base_url('').'application/views/datakey.php') ?>');
			if ( xhr.readyState == 4 && xhr.status == 200 ) {
				// console.log(cari.value);
				wadah.innerHTML = xhr.responseText;
                
			}
		}

        if (cari.value == ""){
            var kata = "kosongasdfg";
        } else {
            var kata = cari.value;
        }
        
        // console.log(kata);

		xhr.open('GET', '<?php echo str_replace('\\', '\\\\', base_url('').'Ink/key/') ?>' + kata, true);
		xhr.send();
	});
</script>

<!-- <script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
	'use strict';
	window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
    	form.addEventListener('submit', function(event) {
    		if (form.checkValidity() === false) {
    			event.preventDefault();
    			event.stopPropagation();
    		}
    		form.classList.add('was-validated');
    	}, false);
    });
}, false);
})();
</script> -->

</body>
</html>