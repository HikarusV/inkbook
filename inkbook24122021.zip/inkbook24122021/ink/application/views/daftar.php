<div class="form">
	<div id="wrap" class="input">
        <section class="input-content">
            <h2>Register</h2>

            <form action="" method="post" novalidate>
                <div class="input-content-wrap">
                    
                    <dl class="inputbox">
                        <dd class="inputbox-content">
                        <input name="input" id="input" type="text" required/>
                        <label for="input">Nama Lengkap</label>
                        <span class="underline"></span>
                        </dd>
                    </dl>

                    <dl class="inputbox">
                        <dd class="inputbox-content">
                            <input name="input0" id="input0" type="text" required/>
                            <label for="input0">username</label>
                            <span class="underline"></span>
                        </dd>
                    </dl>

                    <dl class="inputbox">
                        <dd class="inputbox-content">
                        <input name="input1" id="input1" type="password" required/>
                        <label for="input1">Password</label>
                        <span class="underline"></span>
                        </dd>
                    </dl>

                    <dl class="inputbox">
                        <dd class="inputbox-content">
                        <input name="input2" id="input2" type="text" required/>
                        <label for="input2">Email</label>
                        <span class="underline"></span>
                        </dd>
                    </dl>

                    <div class="btns">
                        <button class="btn btn-confirm" name="regist" type="submit" >Sign Up</button>
                        <button class="btn btn-cancel">Hapus</button>
                    </div>

                </div>
            </form>
        </section>
    </div>
</div>

<div class="regist">
	<a href="<?=base_url('Ink/login')?>">have account? login</a>
</div>