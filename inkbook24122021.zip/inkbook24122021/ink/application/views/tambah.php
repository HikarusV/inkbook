<div class="form2">
	<div id="wrap" class="input">
        <section class="input-content">
            <h2>Tambah Buku</h2>

			<form action="" method="post" enctype="multipart/form-data" novalidate>
				<div class="input-content-wrap">

					<dl class="inputbox">
						<dd class="inputbox-content">
						<input name="input" id="input" type="text" autocomplete="off" required/>
						<label for="input">Judul Buku</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content">
							<input name="input0" id="input0" type="text" autocomplete="off" required value="<?=$this->session->userdata('userid')?>"/>
							<label for="input0">Id Pengarang</label>
							<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content">
						<input name="input1" id="input1" type="text" autocomplete="off" required/>
						<label for="input1">Genre</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content">
						<input name="input2" id="input2" type="number" autocomplete="off" required/>
						<label for="input2">Jumlah Halaman</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content inputbox-content-active">
						<input name="input3" id="input3" type="file" name="gambar" autocomplete="off" required/>
						<label for="input3">Gambar</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content inputbox-content-active">
						<input name="input4" id="input4" type="file" name="berkas" autocomplete="off" required/>
						<label for="input4">E-Book</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<div class="btns">
						<button class="btn btn-confirm" type="submit" name="upload" value="upload">Submit</button>
						<button class="btn btn-cancel">Clear</button>
					</div>

				</div>
			</form>
        </section>
    </div>
</div>