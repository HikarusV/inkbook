<!-- 
	d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm
 -->

 <div class="topnav">
	<!-- <h2 >Home</h2> -->
	<div class="logo">
		<a href="<?=base_url('')?>" class="link">
			<img src="<?=base_url('assets/data/image/ink2.png')?>">
			<h1>ink</h1>
		</a>
	</div>
	<!-- <a href="#about">Buku</a>
	<a href="#about">Artikel</a> -->

	<div class="login-container">
		
			<!-- <input type="text" placeholder="Username" name="username"> -->
			<!-- <button class="in"type="submit">Sign in</button> -->
			<!-- <div class="in">
				<p>Sign in</p>
				<a href="<?=base_url('Ink/login')?>"></a>
			</div> -->
			<?php if (isset($_POST['mybook'])) :?>
				<a class="masuk" href="<?=base_url('Ink/logout')?>">Keluar</a>
			<?php else:?>
				<?php if ($this->session->userdata('login')=='1') :?>
					<a class="masuk" href="<?=base_url('Ink/logout')?>">Keluar</a>
					<a class="masuk" href="<?=base_url('Ink/user')?>">
						<i class="fas fa-book"></i>
					</a>
				<?php else:?> 
					<a class="masuk" href="<?=base_url('Ink/login')?>">Masuk</a>
				<?php endif;?>
			<?php endif;?>

			<div class="search-box">
				<input class="search" type="text" placeholder="Cari" name="search" id="search">
				<a onclick="hideSearchText()" class="cari" id="cari">
				<i class="fas fa-search"></i>
				
				</a>
			</div>
	</div>

</div>
	