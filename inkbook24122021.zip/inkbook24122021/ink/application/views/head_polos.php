<div class="topnav">
	<!-- <h2 >Home</h2> -->
	<div class="logo">
		<a href="<?=base_url('')?>" class="link">
			<img src="<?=base_url('assets/data/image/ink2.png')?>">
			<h1>ink</h1>
		</a>
	</div>

</div>