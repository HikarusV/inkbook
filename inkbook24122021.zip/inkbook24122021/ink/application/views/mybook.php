<?php 
    $this->session->set_userdata('pageuser', '1');

?>

<main id="data">
    <!-- <?=var_dump($item)?> -->
    <h2 class="title-lib">E-Book Library</h2>

        <?php if ($this->session->flashdata('pesan') == 'Ditambah'): ?>
            <div class="notif">
                Buku Berhasil ditambahkan!
            </div>
        <?php elseif ($this->session->flashdata('pesan') == 'Diubah'): ?>
            <div class="notif">
                Data Buku Berhasil Diubah!
            </div>
        <?php elseif ($this->session->flashdata('pesan') == 'Dihapus'): ?>
            <div class="notif">
                Buku Berhasil Dihapus!
            </div>
        <?php endif?>


    <div class="wadah">
        <?php foreach ($item as $value):?>
            <div class="card2">
                <div class="img-box">
                        <img src="data:image/jpg;charset=utf8;base64,<?php echo $value['gambar']; ?>"/>
                </div>
                <div class="info info2">
                    <p>by : <?= $value['pengarang']?></p>
                    <p><?= $value['genre']?></p>
                    <p><?= $value['halaman']?> halaman</p>
                    <a href="<?=base_url($value['url_sumber'])?>"> <button>Baca!</button> </a>
					<div>
						<a href="<?=base_url('ink/edit/'.$value['id_Buku'])?>"> <button>✏️</button> </a>
						<a href="<?=base_url('ink/delete/'.$value['id_Buku'])?>"> <button>🗑️</button> </a>
					</div>
                </div>
                <h2><?= $value['judul']?></h2>
            </div>
        <?php endforeach;?>
			<div class="card">
				<a href="<?=base_url('Ink/add')?>" class="tambah">
					<div class="add">
						<i class="fas fa-plus-circle"></i>
					</div>
				</a>
				
            </div>
			
			
    </div>
</main>