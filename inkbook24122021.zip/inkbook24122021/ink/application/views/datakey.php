<main id="data">
    <h2 class="title-lib">E-Book Library</h2>
    <div class="wadah">
        <?php foreach ($item as $value):?>
            <!-- <?php var_dump($value['judul']) ?> -->
            <div class="card">
                <div class="img-box">
                    <img src="data:image/jpg;charset=utf8;base64,<?php echo $value['gambar']; ?>"/>
                </div>
                <div class="info">
                    <p>by : <?= $value['pengarang']?></p>
                    <p><?= $value['genre']?></p>
                    <p><?= $value['halaman']?> halaman</p>
                    <a href="<?= $value['url_sumber']?>" > <button>Baca!</button> </a>
                </div>
                <h2><?= $value['judul']?></h2>
            </div>
        <?php endforeach;?>
    </div>
</main>