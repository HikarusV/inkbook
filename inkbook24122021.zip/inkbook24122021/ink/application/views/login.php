<div class="form">
	<div id="wrap2" class="input">
        <section class="input-content">
            <h2>Login</h2>

			<?php if ($this->session->flashdata('pesan') == 'daftar'): ?>
            	<div class="notif">
					Registrasi sukses, silahkan login!
				</div>
			<?php endif?>
			
			<form action="" method="post" novalidate>
				<div class="input-content-wrap">
					<dl class="inputbox">
						<dd class="inputbox-content">
							<input name="username" id="username" type="text" autocomplete="off" required/>
							<label for="username">Username/E-mail</label>
							<span class="underline"></span>
						</dd>
					</dl>

					<dl class="inputbox">
						<dd class="inputbox-content">
						<input name="password" id="password" type="password" autocomplete="off" required/>
						<label for="password">Password</label>
						<span class="underline"></span>
						</dd>
					</dl>

					<?php if ($this->session->flashdata('salah_login')): ?>
						<div class="salah" role="alert">
							Username atau Password Salah!
						</div>
					<?php elseif ($this->session->flashdata('belum_login')): ?>
						<div class="salah" role="alert">
							Login Terlebih dahulu !
						</div>
					<?php endif?>

					<div class="btns">
						<button class="btn btn-confirm" name="login" type="submit">Sign In</button>
						<button class="btn btn-cancel" name="clear">Hapus</button>
					</div>

				</div>
			</form>
        </section>
    </div>
</div>

<div class="regist">
	<a href="<?=base_url('Ink/regist')?>">register now</a>
</div>