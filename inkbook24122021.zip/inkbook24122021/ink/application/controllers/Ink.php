<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ink extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Mink');
	}

	public function index() {
		// $data['item'] = $this->Mink->read("ebook");
		$data['item'] = $this->Mink->readMain();
		$this->load->view('source');
		$this->load->view('header');
		$this->load->view('lib', $data);
		$this->load->view('footer');
	}

	public function login() {
		if ($this->session->userdata('login')=='1') {
			redirect('', 'refresh');
		}
		$this->load->view('source');
		$this->load->view('head_polos');
		$this->load->view('login');
		if(isset($_POST['login'])){
			$this->_login();
		}
	}

	private function _login() {

		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$user = $this->db->get_where('pengarang',['user' => $username])->row_array();

		if ($user) {
			// if (password_verify($password, $user['password'])) {
			// 	$this->session->set_userdata('login', '1');
			// 	$this->session->set_userdata('username', $user['username']);
			// 	redirect('', 'refresh');
			// }
			if ($password == $user['pass']) {
				$this->session->set_userdata('login', '1');
				$this->session->set_userdata('userid', $user['user_id']);
				redirect('ink/user', 'refresh');
			}
		} else {
			$this->session->set_flashdata('salah_login', '1');
			// echo("salah cok");
			redirect('ink/login', 'refresh');
		}

	}

	public function logout() {
		session_destroy();
		redirect('','refresh');
	}

	public function regist() {
		$this->load->view('source');
		$this->load->view('head_polos');
		$this->load->view('daftar');
		if(isset($_POST['regist'])){
			$this->Mink->daftar();
		}
	}

	public function user(){
		if ($this->session->userdata('login')=='1') {
			// $data['item'] = $this->Mink->read("ebook");
			$_POST['mybook'] = '';
			$this->session->userdata('pageuser','1');
			$usdat['item'] = $this->Mink->readUser();
			$this->load->view('source');
			$this->load->view('header', $usdat);
			$this->load->view('mybook');
			$this->load->view('footer');
		} else {
			$this->session->set_flashdata('belum_login', '2');
			redirect('ink/login', 'refresh');
		}
	}

	public function add(){
		$this->load->view('source');
		$this->load->view('head_polos');
		$this->load->view('tambah');
		if(isset($_POST['upload'])){
			$this->Mink->create();
		}
	}

	public function edit($id){
		$getDat['item'] = $this->Mink->read_row($id);
		$this->load->view('source');
		$this->load->view('head_polos', $getDat);
		$this->load->view('edit');
		if(isset($_POST['upload'])){
			$this->Mink->ubah($id);
		}
	}

	public function delete($id){
        if ($this->session->userdata('login')=='1') {
			$this->Mink->hapus($id);
			redirect('ink/user', 'refresh');
		} else {
			$this->session->set_flashdata('belum_login', '2');
			redirect('ink/login', 'refresh');
		}
    }
	
	public function key($key){
		if ($this->session->userdata('pageuser')=='1'){
			$data['item'] = $this->Mink->searchMain($key);
			$this->load->view('mybook', $data);
		} else {
			$data['item'] = $this->Mink->searchMain($key);
			$this->load->view('lib', $data);
		}
		
	}

	public function test(){
		echo ("sukses \n");
		$namaFile = "a.php";
		$dirUpload = getcwd()."/assets/data/pdf/";
		$index = 0;
		while (is_file($dirUpload.$namaFile)){
            $namaFile = "x".$namaFile;
			echo($dirUpload.$namaFile);
			echo "\n";
			$index++;
			if ($index > 100){
				die ("stop");
			}
        }

		echo "\n end";
	}
}
