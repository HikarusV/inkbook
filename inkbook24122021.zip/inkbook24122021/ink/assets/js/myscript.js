
		var xhr = new XMLHttpRequest();

		xhr.onreadystatechange = function(){

			if ( xhr.readyState == 4 && xhr.status == 200 ) {
				console.log('File ada');

			} else {
				console.log('File tidak ada');
			}

		}

		xhr.open('GET', 'imgget.php', true);
		xhr.send;

        var x = document.getElementById("search");

        x.addEventListener('keyup', function () {
            
        });